<?php
echo password_hash("1234", PASSWORD_DEFAULT); //this to declare password by run and update database (Admin)
?>

